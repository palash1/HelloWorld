package com.mqtt.core.send;

import java.util.concurrent.BlockingQueue;

import com.mqtt.service.SenderService;


public class SenderProcessTask implements Runnable{
	
	private SenderService senderService;
	private BlockingQueue<Object> senderQueue = null;

	SenderProcessTask( BlockingQueue<Object> senderQueue,SenderService senderService ){
		this.senderQueue = senderQueue;
		this.senderService = senderService;
	}
	@Override
	public void run() {
		while(true) {
			try {
				Object message=senderQueue.take();
				senderService.send(message);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
