package com.mqtt.test;

import org.springframework.stereotype.Service;

import com.mqtt.core.send.SendMessageContainer;
import com.mqtt.message.Email;

@Service
public class Test {
	

	Test(SendMessageContainer container){
		new Thread(()->{
			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		for( Integer i=0; i <500; i++ ) {
    			//gateway.send("foo11" + i ); // THROWS THE ABOVE EXCEPTION
    			Email e1=new Email();
    			e1.setTo("98"+i);
    			e1.setBody("Body"+i);
    			container.put(e1);
    			try {
					Thread.sleep(4000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    	}).start();
	}

}
