package com.mqtt.core.receive;

import java.util.concurrent.BlockingQueue;

import org.springframework.messaging.Message;

public class ReceiverTask implements Runnable{
	
	private  BlockingQueue<Message<?>> receiverQueue =null;
	private BlockingQueue<Message<?>> senderQueue = null;

	ReceiverTask(BlockingQueue<Message<?>> receiverQueue, BlockingQueue<Message<?>> senderQueue){
		this.receiverQueue = receiverQueue;
		this.senderQueue = senderQueue;
	}
	@Override
	public void run() {
		while(true) {
			try {
				Message<?> message= receiverQueue.take();
				senderQueue.add(message);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
