package com.mqtt.core.receive;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import com.mqtt.service.SenderService;


@Service
public class ReceiverMessageContainer{
	
	
	private Thread receiveMessageContainerThread = null;
	private Thread sendMessageContainerThread = null;
	private final BlockingQueue<Message<?>> receiverQueue = new ArrayBlockingQueue<Message<?>>(1024);
	private final BlockingQueue<Message<?>> senderQueue = new ArrayBlockingQueue<Message<?>>(1024);
			
	ReceiverMessageContainer(SenderService senderService){
		ReceiverTask receiverTask =new ReceiverTask(receiverQueue,senderQueue);
		ReceiverProcessTask senderTask =new ReceiverProcessTask(senderQueue,senderService);
		
		receiveMessageContainerThread = new Thread(receiverTask);
		sendMessageContainerThread = new Thread(senderTask);
		start();
	}
	
	private void start() {
		receiveMessageContainerThread.start();
		sendMessageContainerThread.start();
	}
	
	public void put(Message<?> message) {
		receiverQueue.add(message);
	}
}
