package com.mqtt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mqtt.MQTTGateway;
import com.mqtt.utils.JSON;

@Service
public class SenderService {
	
	@Autowired
	private MQTTGateway mqttGateway;
	
	public void send(Object message) {
		
		String messageJSON;
		try {
			messageJSON = JSON.toJson(message);
			mqttGateway.sendToMqtt(messageJSON);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
