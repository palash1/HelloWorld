package com.mqtt.message;

public class Email {
	
	private String to=null;
	private String body=null;
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	@Override
	public String toString() {
		return "Email [to=" + to + ", body=" + body + "]";
	}
	
}
