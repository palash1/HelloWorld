package com.mqtt.core.send;

import java.util.concurrent.BlockingQueue;

public class SenderTask implements Runnable{
	
	private  BlockingQueue<Object> receiverQueue =null;
	private BlockingQueue<Object> senderQueue = null;

	SenderTask(BlockingQueue<Object> receiverQueue, BlockingQueue<Object> senderQueue){
		this.receiverQueue = receiverQueue;
		this.senderQueue = senderQueue;
	}
	@Override
	public void run() {
		while(true) {
			try {
				Object message= receiverQueue.take();
				senderQueue.add(message);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
