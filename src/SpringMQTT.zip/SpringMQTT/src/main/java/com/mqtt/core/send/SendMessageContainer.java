package com.mqtt.core.send;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.springframework.stereotype.Service;

import com.mqtt.service.SenderService;


@Service
public class SendMessageContainer{
	
	
	private Thread receiveMessageContainerThread = null;
	private Thread sendMessageContainerThread = null;
	private final BlockingQueue<Object> receiverQueue = new ArrayBlockingQueue<Object>(1024);
	private final BlockingQueue<Object> senderQueue = new ArrayBlockingQueue<Object>(1024);
			
	SendMessageContainer(SenderService senderService){
		SenderTask receiverTask =new SenderTask(receiverQueue,senderQueue);
		SenderProcessTask senderTask =new SenderProcessTask(senderQueue,senderService);
		
		receiveMessageContainerThread = new Thread(receiverTask);
		sendMessageContainerThread = new Thread(senderTask);
		start();
	}
	
	private void start() {
		receiveMessageContainerThread.start();
		sendMessageContainerThread.start();
	}
	
	public void put(Object message) {
		receiverQueue.add(message);
	}
}
