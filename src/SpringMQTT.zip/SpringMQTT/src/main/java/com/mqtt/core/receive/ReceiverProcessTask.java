package com.mqtt.core.receive;

import java.io.IOException;
import java.util.concurrent.BlockingQueue;

import org.springframework.messaging.Message;

import com.mqtt.message.Email;
import com.mqtt.service.SenderService;
import com.mqtt.utils.JSON;


public class ReceiverProcessTask implements Runnable{
	
	@SuppressWarnings("unused")
	private SenderService senderService;
	private BlockingQueue<Message<?>> senderQueue = null;

	ReceiverProcessTask( BlockingQueue<Message<?>> senderQueue,SenderService senderService ){
		this.senderQueue = senderQueue;
		this.senderService = senderService;
	}
	@Override
	public void run() {
		while(true) {
			try {
				Message<?> message=senderQueue.take();
				try {
					//System.out.println("Receive1::" + message.getPayload().toString());
					Email ee= JSON.fromJson(message.getPayload().toString(), Email.class);
					System.out.println("Receive::" + ee);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				 
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
