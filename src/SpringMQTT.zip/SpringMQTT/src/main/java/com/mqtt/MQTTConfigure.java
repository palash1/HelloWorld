package com.mqtt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageProducer;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.integration.mqtt.support.DefaultPahoMessageConverter;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;


@SpringBootApplication
@Configuration
public class MQTTConfigure {

	@Autowired
    private Environment env;
	
    @Bean
    public MqttPahoClientFactory mqttClientFactory() {
    	
    	String mqttURL = env.getProperty("mqtt.url");
    	String userName =  env.getProperty("mqtt.username");
    	String userPassword =  env.getProperty("mqtt.password");
    	
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        factory.setServerURIs(mqttURL);
        factory.setUserName(userName);
        factory.setPassword(userPassword);
        return factory;
    }

    @Bean
    public MessageProducer inbound( MqttPahoClientFactory mqttClientFactory) {
    	String receiverClientName =  env.getProperty("mqtt.receiverClientName");
    	String receiverZTopicName =  env.getProperty("mqtt.receiverTopicName");
    	
        MqttPahoMessageDrivenChannelAdapter adapter =
                new MqttPahoMessageDrivenChannelAdapter(receiverClientName,mqttClientFactory,receiverZTopicName);
        adapter.setCompletionTimeout(5000);
        adapter.setConverter(new DefaultPahoMessageConverter());
        adapter.setQos(1);
        adapter.setOutputChannel(mqttInputChannel());
      
        return adapter;
    }
    
    @Bean
    @ServiceActivator(inputChannel = "mqttOutboundChannel")
    public MessageHandler mqttOutbound(MqttPahoClientFactory mqttClientFactory) {
    	String senderClientName =  env.getProperty("mqtt.senderClientName");
    	String senderTopicName =  env.getProperty("mqtt.senderTopicName");
    	
        MqttPahoMessageHandler messageHandler =
                       new MqttPahoMessageHandler(senderClientName, mqttClientFactory);
        messageHandler.setAsync(true);
        messageHandler.setDefaultTopic(senderTopicName);
        return messageHandler;
    }
    
    @Bean("mqttOutboundChannel")
    public MessageChannel mqttOutboundChannel() {
        return new DirectChannel();
    }
    
    @Bean("mqttInputChannel")
    public MessageChannel mqttInputChannel() {
        return new DirectChannel();
    }

    @Bean
    @ServiceActivator(inputChannel = "mqttInputChannel")
    public MessageHandler handler(MessageReceiverListener messageReceiverListener) {
        return messageReceiverListener;
    }

}
