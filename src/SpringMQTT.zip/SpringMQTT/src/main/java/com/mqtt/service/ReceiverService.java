package com.mqtt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import com.mqtt.core.receive.ReceiverMessageContainer;

@Service
public class ReceiverService {
	
	@Autowired
	private ReceiverMessageContainer receiverMessageContainer;
	
	public void receive(Message<?> message){
	
		receiverMessageContainer.put(message);
	}

}
